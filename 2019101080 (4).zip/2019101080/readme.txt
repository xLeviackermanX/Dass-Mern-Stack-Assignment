To run this web-app use following commands:-

in frontend:-
npm install

in backend:-
npm install;
npm run dev;

