module.exports = {
    mongoURI: "mongodb+srv://priyansh5525:shreya5525@cluster0.k7obg.mongodb.net/app_db?retryWrites=true&w=majority", 
    secretOrKey: "secret"
  };
  